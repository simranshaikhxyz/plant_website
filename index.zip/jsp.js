

// Plant data
const plantData = {
    "Mango": {
        name: "Mango",
        scientific_name: "Mangifera indica",
        type: "Evergreen fruit tree",
        lifespan: "30–40 yrs",
        height: "Up to ~45 m",
        oxygen_level: "High (large canopy)",
        description: "The mango is a tropical fruit known as the king of fruits. Sweet, juicy flesh with a large flat seed. Rich in vitamins and fiber.",
        location: "South Asia (India, Myanmar, Bangladesh)",
        used_for: "Fruits eaten fresh, in pickles, juices; wood used in furniture; leaves used in rituals",
        sci_fic_uses: "Edible fruit; medicinal: leaves and bark have antioxidant, anti-inflammatory, anti-cancer properties; industrial: mango seed oil for cosmetics and chocolate substitute",
        more_info_link: "https://en.wikipedia.org/wiki/Mango",
        video_link: "https://www.youtube.com/results?search_query=Mangifera+indica+plant",
        photo: "plantimg/mango.jpeg"
    },
    "Hairy Fig": {
        name: "Hairy Fig",
        scientific_name: "Ficus hirta",
        type: "Small/medium fig tree/shrub",
        lifespan: "50–150 yrs",
        height: "3–10 m",
        oxygen_level: "Moderate",
        description: "Tree with broad, rough leaves and hairy fruits. Used in traditional medicine for digestive and skin problems.",
        location: "Tropical Asia (SE China, S/E Asia, India)",
        used_for: "Fruits edible; bark and roots used in traditional medicine",
        sci_fic_uses: "Medicinal extracts studied for antidiabetic, hepatoprotective, antimicrobial activity; latex has wound healing potential",
        more_info_link: "https://en.wikipedia.org/wiki/Ficus_hirta",
        video_link: "https://www.youtube.com/results?search_query=Hairy+Fig+plant",

        photo: "plantimg/hairyfig.jpeg"
    },
    "Heena": {
        name: "Heena",
        scientific_name: "Lawsonia inermis",
        type: "Deciduous shrub",
        lifespan: "20–50 yrs",
        height: "1–6 m",
        oxygen_level: "Low–Moderate",
        description: "Shrub native to South Asia & North Africa. Leaves used for natural dye (mehendi) and medicinal purposes.",
        location: "South Asia & North Africa",
        used_for: "Leaves for natural dye; medicinal for skin and fever",
        sci_fic_uses: "Natural dye (lawsone compound); antibacterial and antifungal properties; used in nanoparticle synthesis in green chemistry",
        more_info_link: "https://en.wikipedia.org/wiki/Lawsonia_inermis",
        video_link: "https://www.youtube.com/results?search_query=heena+plant",
        photo: "plantimg/heena (2).jpeg"
    },
    "Areca palm": {
        name: "Areca palm",
        scientific_name: "Dypsis lutescens",
        type: "Clustering palm",
        lifespan: "20–50 yrs",
        height: "2–12 m (indoor 1–3 m)",
        oxygen_level: "Moderate (good indoor)",
        description: "Tropical palm with arching fronds, purifies indoor air. Often planted for ornamental use.",
        location: "Madagascar",
        used_for: "Nuts chewed with betel leaves; wood/leaves used in handicrafts; ornamental indoor/outdoor plant",
        sci_fic_uses: "Nuts contain alkaloid arecoline studied for CNS effects; used in traditional medicine, caution for oral cancer",
        more_info_link: "https://en.wikipedia.org/wiki/Dypsis_lutescens",
        video_link: "https://www.youtube.com/results?search_query=areca+palm+",

        photo: "plantimg/areca plam.jpeg"
    },
    "Song of India": {
        name: "Song of India",
        scientific_name: "Dracaena reflexa",
        type: "Evergreen shrub / small tree",
        lifespan: "20–50 yrs",
        height: "2–6 m (cultivated)",
        oxygen_level: "Moderate (indoor purifier)",
        description: "Decorative evergreen shrub admired for striking green and yellow leaves.",
        location: "Madagascar / Indian Ocean islands",
        used_for: "Ornamental indoor plant; air-purifying qualities",
        sci_fic_uses: "NASA study: Air-purifying, removes VOCs",
        more_info_link: "https://en.wikipedia.org/wiki/Dracaena_reflexa",
        video_link: "https://www.youtube.com/results?search_query=song+of+india+plant",

        photo: "plantimg/songofindia.jpeg"
    },
    "Money Plant": {
        name: "Money Plant",
        scientific_name: "Epipremnum aureum",
        type: "Evergreen vine / climber",
        lifespan: "5–20+ yrs (clonal)",
        height: "Climbs up to 10–20 m on supports; trailing otherwise",
        oxygen_level: "Moderate (effective indoor purifier)",
        description: "Hardy vine, often grown in soil or water indoors, believed to bring prosperity.",
        location: "Solomon Islands / tropical Asia (widespread naturalized)",
        used_for: "Ornamental creeper; indoor air purifier",
        sci_fic_uses: "Air purifier (formaldehyde, benzene removal); tissue culture research for rapid propagation",
        more_info_link: "https://en.wikipedia.org/wiki/Epipremnum_aureum",
        video_link: "https://www.youtube.com/results?search_query=money+plant",

        photo: "plantimg/money.jpeg"
    },
    "Phillipine Tea Tree": {
        name: "Phillipine Tea Tree",
        scientific_name: "Ehretia microphylla",
        type: "Evergreen shrub / small tree",
        lifespan: "20–50 yrs",
        height: "1–6 m",
        oxygen_level: "Low–Moderate",
        description: "Small evergreen shrub with shiny green leaves and small white flowers. Used as bonsai.",
        location: "Southeast Asia (Philippines region)",
        used_for: "Bonsai; leaves used in traditional herbal tea for cough and colds",
        sci_fic_uses: "Leaves contain flavonoids and tannins; studied for antimicrobial activity; used in herbal teas for digestive health",
        more_info_link: "https://en.wikipedia.org/wiki/Ehretia_microphylla",
        video_link: "https://www.youtube.com/results?search_query=philippine+tea+tree",

        photo: "plantimg/phtea.jpeg"
    },
    "Bumpy Lemon": {
        name: "Bumpy Lemon",
        scientific_name: "Citrus Jambhiri",
        type: "Evergreen citrus tree",
        lifespan: "50–100 yrs",
        height: "4–8 m",
        oxygen_level: "Moderate",
        description: "Citrus tree with thick, rough-skinned fruits. Juice used in beverages and pickles.",
        location: "South / Southeast Asia (cultivated widely)",
        used_for: "Fruits used in pickles, beverages; medicinal for cold, sore throat, digestion",
        sci_fic_uses: "High vitamin C and antioxidants; extracts studied for antimicrobial and anti-inflammatory activity",
        more_info_link: "https://en.wikipedia.org/wiki/Citrus_jambhiri",
        video_link: "https://www.youtube.com/results?search_query=bumpy+lemon+plant",

        photo: "plantimg/bumpy lemon.jfif"
    },
    "Coconut Tree": {
        name: "Coconut Tree",
        scientific_name: "Cocus Nucifera",
        type: "Tall palm",
        lifespan: "60–80 yrs (productive decades)",
        height: "20–30 m (varies)",
        oxygen_level: "High (coastal, large leaf area)",
        description: "Tall palm, called 'tree of life'. Every part is useful: fruit, leaves, trunk.",
        location: "Tropical coastal regions (Indo-Pacific origin)",
        used_for: "Coconut water, milk, oil; husk for coir; leaves for mats and roofing; used in rituals",
        sci_fic_uses: "Coconut oil in nanomedicine; activated carbon from shells for water purification; lauric acid shows antiviral effects",
        more_info_link: "https://en.wikipedia.org/wiki/Cocos_nucifera",
        video_link: "https://www.youtube.com/results?search_query=coconut+tree",

        photo: "plantimg/coconut.jpeg"
    },
    "Hibiscus": {
        name: "Hibiscus",
        scientific_name: "Hibiscus rosa-sinensis",
        type: "Evergreen / semi-deciduous shrub",
        lifespan: "5–30 yrs (garden plants)",
        height: "1–4 m",
        oxygen_level: "Low–Moderate",
        description: "Flowering shrub with colorful blooms. Flowers used in teas and hair care.",
        location: "Tropical Asia (widely cultivated)",
        used_for: "Ornamental flowers; used in hair oils, shampoos; medicinal for skin and blood purification; flowers offered in worship",
        sci_fic_uses: "Hibiscus tea lowers blood pressure; extracts studied for anti-diabetic and anti-cancer properties",
        more_info_link: "https://en.wikipedia.org/wiki/Hibiscus_rosa-sinensis",
        video_link: "https://www.youtube.com/results?search_query=hibiscus+plant",

        photo: "plantimg/hibiscus (2).jpeg"
    },
    "Tiplant": {
        name: "Tiplant",
        scientific_name: "Cordyline fruticosa",
        type: "Evergreen shrub",
        lifespan: "10–30 yrs",
        height: "1–4 m",
        oxygen_level: "Moderate",
        description: "Ornamental shrub with broad, colorful leaves. Associated with good luck.",
        location: "Southeast Asia & Pacific Islands",
        used_for: "Ornamental foliage plant; leaves used in traditional rituals and wrapping food",
        sci_fic_uses: "Used in genetic studies as ornamental model; contains saponins with antibacterial effects",
        more_info_link: "https://en.wikipedia.org/wiki/Cordyline_fruticosa",
        video_link: "https://www.youtube.com/results?search_query=tiplant",

        photo: "plantimg/tiplant.jpeg"
    },
    "ashoka Tree": {
        name: "Ashoka Tree",
        scientific_name: "Saraca asoca",
        type: "Evergreen small tree",
        lifespan: "50–100 yrs",
        height: "6–9 m",
        oxygen_level: "Moderate–High",
        description: "Sacred evergreen tree with fragrant orange-red flowers. Bark used in Ayurveda for women's health.",
        location: "Indian subcontinent & Sri Lanka",
        used_for: "Medicinal bark; sacred tree in Indian culture",
        sci_fic_uses: "Bark extract studied for uterine health, anti-cancer, antioxidant properties",
        more_info_link: "https://en.wikipedia.org/wiki/Saraca_asoca",
        video_link: "https://www.youtube.com/results?search_query=ashoka+tree",

        photo: "plantimg/Ashoka.jpeg"
    },
    "Firespike": {
        name: "Firespike",
        scientific_name: "Odontonema strictum",
        type: "Perennial ornamental shrub",
        lifespan: "5–10+ yrs (perennial)",
        height: "1–2 m",
        oxygen_level: "Low",
        description: "Tropical shrub with bright red tubular flowers, attracts hummingbirds and butterflies.",
        location: "Central America (cultivated tropics)",
        used_for: "Ornamental shrub with red flowers; attracts pollinators",
        sci_fic_uses: "Leaves studied for antibacterial and antifungal activity; nectar attracts pollinators → ecological importance",
        more_info_link: "https://en.wikipedia.org/wiki/Odontonema_strictum",
        video_link: "https://www.youtube.com/results?search_query=firespike+plant",

        photo: "plantimg/firespike.jpeg"
    },
    "Dwarf Umbrella Tree": {
        name: "Dwarf Umbrella Tree",
        scientific_name: "Schefflera arboricola",
        type: "Evergreen shrub/small tree",
        lifespan: "15–30 yrs",
        height: "1–3 m",
        oxygen_level: "Moderate (good indoor plant)",
        description: "Compact indoor plant with umbrella-like leaf clusters.",
        location: "Taiwan, Hainan Island",
        used_for: "Ornamental indoor plant; air purification",
        sci_fic_uses: "NASA study: removes VOCs indoors",
        more_info_link: "https://en.wikipedia.org/wiki/Schefflera_arboricola",
        video_link: "https://www.youtube.com/results?search_query=dwarf+umbrella+plant",

        photo: "plantimg/dwarf.jpeg"
    },
    "Indica": {
        name: "Indica",
        scientific_name: "Cannabis indica",
        type: "Annual herbaceous plant",
        lifespan: "1 yr (annual)",
        height: "0.5–2 m",
        oxygen_level: "Low",
        description: "Cannabis species used for medicinal, recreational, and industrial purposes.",
        location: "Central/South Asia",
        used_for: "Medicinal, recreational, fiber production",
        sci_fic_uses: "Cannabinoids studied for pain, epilepsy, nausea, neurodegenerative diseases",
        more_info_link: "https://en.wikipedia.org/wiki/Cannabis_indica",
        video_link: "https://www.youtube.com/results?search_query=indica+plant+",

        photo: "plantimg/indica.jfif"
    },
    "Sida Rhombifolia": {
        name: "Sida Rhombifolia",
        scientific_name: "Sida rhombifolia",
        type: "Perennial shrub",
        lifespan: "2–10 yrs",
        height: "0.5–2 m",
        oxygen_level: "Low",
        description: "Shrub used traditionally in medicine for fever, inflammation, and pain relief.",
        location: "Tropical and subtropical regions worldwide",
        used_for: "Medicinal: anti-inflammatory, analgesic, diuretic",
        sci_fic_uses: "Extracts studied for antibacterial, antifungal, and antioxidant properties",
        more_info_link: "https://en.wikipedia.org/wiki/Sida_rhombifolia",
        video_link: "https://www.youtube.com/results?search_query=sida+rhombifolia",

        photo: "plantimg/sida.jpeg"
    },
    "Bauhinia Species": {
        name: "Bauhinia Species",
        scientific_name: "Bauhinia spp.",
        type: "Deciduous/evergreen trees",
        lifespan: "20–50 yrs",
        height: "3–15 m",
        oxygen_level: "Moderate",
        description: "Trees with orchid-like flowers; leaves bilobed like camel's foot.",
        location: "Tropical & subtropical Asia, Africa",
        used_for: "Ornamental; traditional medicine for diabetes and inflammation",
        sci_fic_uses: "Flavonoid-rich extracts studied for antioxidant, antidiabetic properties",
        more_info_link: "https://en.wikipedia.org/wiki/Bauhinia",
        video_link: "https://www.youtube.com/results?search_query=bauhinia+plant",

        photo: "plantimg/bauhinia.jpeg"
    },
    "FIg": {
        name: "Fig",
        scientific_name: "Ficus carica",
        type: "Deciduous small tree",
        lifespan: "50–100 yrs",
        height: "3–10 m",
        oxygen_level: "Moderate",
        description: "Fruiting tree producing sweet figs, cultivated for edible fruit.",
        location: "Mediterranean, Western Asia",
        used_for: "Fruits eaten fresh/dried; medicinal for digestion",
        sci_fic_uses: "Fig extracts studied for antioxidant, anti-inflammatory, anti-cancer activity",
        more_info_link: "https://en.wikipedia.org/wiki/Ficus_carica",
        video_link: "https://www.youtube.com/results?search_query=fig+plant",

        photo: "plantimg/ficus careca.jpg"
    },
    "Frangipani": {
        name: "Frangipani",
        scientific_name: "Plumeria spp.",
        type: "Deciduous flowering tree",
        lifespan: "20–50 yrs",
        height: "3–8 m",
        oxygen_level: "Low–Moderate",
        description: "Tree with fragrant flowers; commonly used in tropical landscaping and religious ceremonies.",
        location: "Tropical Americas",
        used_for: "Ornamental; flowers in garlands and rituals",
        sci_fic_uses: "Fragrance contains compounds with antioxidant, antimicrobial, insect repellent potential",
        more_info_link: "https://en.wikipedia.org/wiki/Plumeria",
        video_link: "https://www.youtube.com/results?search_query=frangipani+plant",

        photo: "plantimg/frangipani.jpeg"
    },
    "Bamboo": {
        name: "Bamboo",
        scientific_name: "Bambusoideae",
        type: "Grass / woody plant",
        lifespan: "5–120 yrs depending on species",
        height: "1–30 m",
        oxygen_level: "High (fast-growing, carbon sequester)",
        description: "Fast-growing grass; used for construction, furniture, food, and textiles.",
        location: "Worldwide tropical & subtropical Asia, Africa, Americas",
        used_for: "Construction, crafts, edible shoots, paper, furniture",
        sci_fic_uses: "Sustainable material; bioengineering for scaffolds, paper, biofuel",
        more_info_link: "https://en.wikipedia.org/wiki/Bamboo",
        video_link: "https://www.youtube.com/results?search_query=bamboo+plant",

        photo: "plantimg/bamboo.jpeg"
    },
    "Almond Tree": {
        name: "Almond Tree",
        scientific_name: "Prunus dulcis",
        type: "Deciduous tree",
        lifespan: "30–50 yrs",
        height: "4–10 m",
        oxygen_level: "Moderate",
        description: "Nut-producing tree with fragrant white-pink flowers.",
        location: "Middle East, South Asia (cultivated worldwide)",
        used_for: "Almond nuts for food; oil for cosmetics and cooking",
        sci_fic_uses: "Almond oil and extracts studied for cardiovascular benefits; antimicrobial; cosmetic uses",
        more_info_link: "https://en.wikipedia.org/wiki/Almond",
        video_link: "https://www.youtube.com/results?search_query=almond+tree",

        photo: "plantimg/almond.jpeg"
    },
    "Duranta": {
        name: "Duranta",
        scientific_name: "Duranta erecta",
        type: "Evergreen shrub / small tree",
        lifespan: "10–20 yrs",
        height: "1–6 m",
        oxygen_level: "Low–Moderate",
        description: "Shrub with bright flowers (purple/yellow) and golden berries; ornamental and hedge plant.",
        location: "Tropical Americas",
        used_for: "Ornamental, hedges, attracts birds",
        sci_fic_uses: "Berries contain compounds studied for antioxidant activity; ornamental landscaping applications",
        more_info_link: "https://en.wikipedia.org/wiki/Duranta_erecta",
        video_link: "https://www.youtube.com/results?search_query=duranta+plant",

        photo: "plantimg/duranta.jpeg"
    },
    "Cherry Tree": {
        name: "Cherry Tree",
        scientific_name: "Prunus avium / Prunus cerasus",
        type: "Deciduous fruit tree",
        lifespan: "15–100 yrs (varies by species)",
        height: "4–15 m",
        oxygen_level: "Moderate",
        description: "Trees producing sweet or sour cherries, widely cultivated for fruit and ornamental blossoms.",
        location: "Europe, Asia Minor, North America (cultivated)",
        used_for: "Fruit consumption; ornamental flowering trees",
        sci_fic_uses: "Cherry extracts studied for antioxidant, anti-inflammatory properties; anthocyanins for health benefits",
        more_info_link: "https://en.wikipedia.org/wiki/Cherry",
        video_link: "https://www.youtube.com/results?search_query=cherry+tree",

        photo: "plantimg/cherry.jpeg"
    },
    "Bean Plant": {
        name: "Bean Plant",
        scientific_name: "Phaseolus vulgaris",
        type: "Annual climbing herb",
        lifespan: "1 yr",
        height: "0.3–2 m",
        oxygen_level: "Low",
        description: "Climbing herb producing edible beans; staple in diets worldwide.",
        location: "Central and South America",
        used_for: "Edible beans (fresh, dried), soil nitrogen fixation",
        sci_fic_uses: "Rich in proteins and minerals; extracts studied for antioxidant activity",
        more_info_link: "https://en.wikipedia.org/wiki/Phaseolus_vulgaris",
        video_link: "https://www.youtube.com/results?search_query=bean+plant",

        photo: "plantimg/bean (2).jpeg"
    },
    "Jackfruit": {
        name: "Jackfruit",
        scientific_name: "Artocarpus heterophyllus",
        type: "Evergreen large tree",
        lifespan: "50–100 yrs",
        height: "10–25 m",
        oxygen_level: "High",
        description: "Tropical tree producing largest edible fruit; fibrous fruit used as meat substitute.",
        location: "South & Southeast Asia",
        used_for: "Fruit eaten raw/cooked; seeds edible; wood for furniture",
        sci_fic_uses: "Jackfruit compounds studied for antioxidant, anti-inflammatory, antidiabetic potential; meat substitute in plant-based diets",
        more_info_link: "https://en.wikipedia.org/wiki/Jackfruit",
        video_link: "https://www.youtube.com/results?search_query=jackfruit+tree",

        photo: "plantimg/jacfruit.jpeg"
    },
    "Bay Laurel": {
        name: "Bay Laurel",
        scientific_name: "Laurus nobilis",
        type: "Evergreen tree/shrub",
        lifespan: "50–100+ yrs",
        height: "7–18 m",
        oxygen_level: "Moderate",
        description: "Aromatic evergreen tree used in cooking (bay leaves) and traditional medicine.",
        location: "Mediterranean region",
        used_for: "Leaves as spice; ornamental; traditional medicine",
        sci_fic_uses: "Essential oils studied for antimicrobial, antioxidant, anti-inflammatory activity",
        more_info_link: "https://en.wikipedia.org/wiki/Laurus_nobilis",
        video_link: "https://www.youtube.com/results?search_query=bay+laurel+plant",

        photo: "plantimg/baylaurel.jpeg"
    },
    "Natal Plum": {
        name: "Natal Plum",
        scientific_name: "Carissa macrocarpa",
        type: "Evergreen shrub",
        lifespan: "10–20 yrs",
        height: "1–3 m",
        oxygen_level: "Low–Moderate",
        description: "Shrub producing red edible fruits; used for landscaping, hedges, and coastal planting.",
        location: "South Africa",
        used_for: "Edible fruit; ornamental hedges; soil stabilization",
        sci_fic_uses: "Fruit extracts studied for antioxidant activity; landscaping applications in saline soils",
        more_info_link: "https://en.wikipedia.org/wiki/Carissa_macrocarpa",
        video_link: "https://www.youtube.com/results?search_query=natal+plum+plant",

        photo: "plantimg/natalpalm.jpeg"
    },
    "Red river Fig": {
        name: "Red river Fig",
        scientific_name: "Ficus rubiginosa",
        type: "Evergreen tree",
        lifespan: "50–100 yrs",
        height: "15–30 m",
        oxygen_level: "High",
        description: "Native fig tree with reddish bark and edible figs. Popular in parks and landscaping.",
        location: "Australia (native), cultivated elsewhere",
        used_for: "Ornamental; edible figs; shade",
        sci_fic_uses: "Latex studied for antibacterial and wound healing; figs for nutrition and antioxidants",
        more_info_link: "https://en.wikipedia.org/wiki/Ficus_rubiginosa",
        video_link: "https://www.youtube.com/results?search_query=red+river+fig+plant",

        photo: "plantimg/castoroil.jpeg"
    },
    "Lasura": {
        name: "Lasura",
        scientific_name: "Cordia myxa",
        type: "Deciduous medium tree",
        lifespan: "30–60 yrs",
        height: "6–12 m",
        oxygen_level: "Moderate",
        description: "Medium-sized tree with round yellowish edible fruits. Fruits and leaves used in traditional medicine.",
        location: "South Asia, Middle East",
        used_for: "Fruits edible (pickles, chutneys); bark and leaves medicinal",
        sci_fic_uses: "Fruits rich in mucilage, used as natural drug binder; antioxidant and hepatoprotective properties studied",
        more_info_link: "https://en.wikipedia.org/wiki/Cordia_myxa",
        video_link: "https://www.youtube.com/results?search_query=lasura+plant",

        photo: "plantimg/lasura.jpeg"
    },
    "Headache Tree": {
        name: "Headache Tree",
        scientific_name: "Premna serratifolia",
        type: "Evergreen shrub / small tree",
        lifespan: "20–50 yrs",
        height: "3–10 m",
        oxygen_level: "Moderate",
        description: "Flowering tree known for bright red pea-shaped flowers. Bark and leaves used in traditional medicine.",
        location: "India → SE Asia, Australia",
        used_for: "Leaves and roots medicinal for headaches, cough, fever; used in Ayurveda",
        sci_fic_uses: "Potential in herbal formulations for stress relief; neuroprotective and antioxidant properties",
        more_info_link: "https://en.wikipedia.org/wiki/Premna_serratifolia",
        video_link: "https://www.youtube.com/results?search_query=headache+tree",

        photo: "plantimg/headachetree.jpeg"
    },
    "Tulsi": {
        name: "Tulsi",
        scientific_name: "Ocimum tenuiflorum",
        type: "Annual / short-lived perennial herb",
        lifespan: "1–5 yrs (perennial in tropics)",
        height: "0.3–1 m",
        oxygen_level: "Low",
        description: "Sacred plant in India with medicinal, aromatic, and spiritual significance. Leaves used in teas and remedies.",
        location: "Indian subcontinent",
        used_for: "Sacred plant; medicinal for cough, cold, immunity; leaves used in tea and rituals",
        sci_fic_uses: "Scientifically proven adaptogen; antimicrobial, anti-cancer, and immunity-boosting properties; used in nanoformulations for drug delivery",
        more_info_link: "https://en.wikipedia.org/wiki/Ocimum_tenuiflorum",
        video_link: "https://www.youtube.com/results?search_query=tulsi+tree",

        photo: "plantimg/tulsi.jpeg"
    },
    "Peepal": {
        name: "Peepal",
        scientific_name: "Ficus religiosa",
        type: "Large deciduous / semi-evergreen tree",
        lifespan: "Centuries (often several hundred years)",
        height: "20–30 m (can be larger)",
        oxygen_level: "High",
        description: "Sacred fig tree known for heart-shaped leaves. Revered in Hinduism, Buddhism, and Jainism. Releases oxygen even at night.",
        location: "Indian subcontinent & SE Asia",
        used_for: "Worship, shade, air purification, traditional medicine",
        sci_fic_uses: "Could be used as a 'living oxygen generator' in future smart cities",
        more_info_link: "https://en.wikipedia.org/wiki/Ficus_religiosa",
        video_link: "https://www.youtube.com/results?search_query=peepal+tree",

        photo: "plantimg/peepal.jfif"
    },
    "Golden Pothos (Devil's Ivy)": {
        name: "Golden Pothos (Devil's Ivy)",
        scientific_name: "Epipremnum aureum",
        type: "Evergreen vine / climber",
        lifespan: "5–20+ yrs (clonal)",
        height: "Climbs up to 10–20 m on supports",
        oxygen_level: "Moderate (indoor air purifier)",
        description: "Hardy climbing vine popular as ornamental indoor plant. Thrives in low light, easy care.",
        location: "Solomon Islands / tropical Asia",
        used_for: "Indoor air purifier, ornamental plant",
        sci_fic_uses: "Future bio-filters in space stations",
        more_info_link: "https://en.wikipedia.org/wiki/Epipremnum_aureum",
        video_link: "https://www.youtube.com/results?search_query=golden+pothos+plant",

        photo: "plantimg/golden pothos.jfif"
    },
    "Gynura Procumbens": {
        name: "Gynura Procumbens",
        scientific_name: "Gynura procumbens",
        type: "Perennial creeping herb",
        lifespan: "2–5 yrs (perennial)",
        height: "0.3–0.5 m",
        oxygen_level: "Low",
        description: "Creeping herb used in Southeast Asian traditional medicine.",
        location: "Southeast Asia",
        used_for: "Leaves used for diabetes, hypertension, and inflammation",
        sci_fic_uses: "Extracts studied for anti-hyperglycemic, anti-inflammatory, and antioxidant properties",
        more_info_link: "https://en.wikipedia.org/wiki/Gynura_procumbens",
        video_link: "https://www.youtube.com/results?search_query=gynura+procumbens+plant",

        photo: "plantimg/gynura.jfif"
    },
    "Custard Apple": {
        name: "Custard Apple",
        scientific_name: "Annona squamosa",
        type: "Small deciduous fruit tree",
        lifespan: "20–50 yrs",
        height: "3–8 m",
        oxygen_level: "Moderate",
        description: "Tree producing sweet, creamy fruits with segmented flesh.",
        location: "Tropical Americas / South Asia",
        used_for: "Fruit eaten fresh; seeds and leaves used in traditional medicine",
        sci_fic_uses: "Fruit contains antioxidants; leaves studied for antidiabetic, antimicrobial properties",
        more_info_link: "https://en.wikipedia.org/wiki/Annona_squamosa",
        video_link: "https://www.youtube.com/results?search_query=custard+apple+plant",

        photo: "plantimg/custred apple.jfif"
    },
    "Magnolia": {
        name: "Magnolia",
        scientific_name: "Magnolia spp.",
        type: "Deciduous/evergreen trees",
        lifespan: "50–80+ yrs",
        height: "10–30 m",
        oxygen_level: "Moderate–High",
        description: "Ornamental flowering trees with large, fragrant flowers.",
        location: "Asia, Americas",
        used_for: "Ornamental; flowers used in perfumes; some species in medicine",
        sci_fic_uses: "Essential oils studied for antimicrobial, anti-inflammatory, and cosmetic applications",
        more_info_link: "https://en.wikipedia.org/wiki/Magnolia",
        video_link: "https://www.youtube.com/results?search_query=magnolia+plant",

        photo: "plantimg/Mongolia.jpeg"
    },
    "Anacus": {
        name: "Cashew",
        scientific_name: "Anacardium occidentale",
        type: "Evergreen tree",
        lifespan: "30–40 yrs",
        height: "8–12 m",
        oxygen_level: "Moderate",
        description: "Tropical tree producing cashew nuts and cashew apples.",
        location: "Brazil (native), cultivated tropics",
        used_for: "Nuts edible; fruit juice; wood and shell uses",
        sci_fic_uses: "Cashew nut extracts studied for antioxidant, antimicrobial activity; cashew shell oil industrial use",
        more_info_link: "https://en.wikipedia.org/wiki/Cashew",
        video_link: "https://www.youtube.com/results?search_query=anacus+plant",

        photo: "plantimg/cashew.jfif"
    },
    "Guava": {
        name: "Guava",
        scientific_name: "Psidium guajava",
        type: "Evergreen fruit tree",
        lifespan: "20–40 yrs",
        height: "3–10 m",
        oxygen_level: "Moderate",
        description: "Tropical fruit tree producing sweet or sour fruits rich in vitamin C.",
        location: "Central America, tropical Asia",
        used_for: "Fruit consumption; medicinal for digestion, diabetes",
        sci_fic_uses: "Guava leaves and fruit extracts studied for antimicrobial, antioxidant, anti-diabetic properties",
        more_info_link: "https://en.wikipedia.org/wiki/Guava",
        video_link: "https://www.youtube.com/results?search_query=guava+plant+",

        photo: "plantimg/Guava.jpeg"
    },
    "Honeysuckle": {
        name: "Honeysuckle",
        scientific_name: "Lonicera spp.",
        type: "Climbing shrub / vine",
        lifespan: "5–20 yrs",
        height: "1–6 m",
        oxygen_level: "Low–Moderate",
        description: "Flowering vine with sweet-smelling tubular flowers.",
        location: "Northern Hemisphere",
        used_for: "Ornamental; flowers attract pollinators; traditional medicine",
        sci_fic_uses: "Extracts studied for antibacterial, antiviral, anti-inflammatory properties",
        more_info_link: "https://en.wikipedia.org/wiki/Honeysuckle",
        video_link: "https://www.youtube.com/results?search_query=honeysuckle+plant",

        photo: "plantimg/honeysuckle.jfif"
    },
    "Arrowhead Vine": {
        name: "Arrowhead Vine",
        scientific_name: "Syngonium podophyllum",
        type: "Evergreen climbing vine",
        lifespan: "5–15 yrs",
        height: "Climbs or trails 1–3 m indoors",
        oxygen_level: "Moderate (indoor)",
        description: "Popular indoor plant with arrow-shaped leaves. Easy to grow and propagate.",
        location: "Central and South America",
        used_for: "Indoor ornamental; improves air quality",
        sci_fic_uses: "NASA study: air purification; contains flavonoids studied for antimicrobial activity",
        more_info_link: "https://en.wikipedia.org/wiki/Syngonium_podophyllum",
        video_link: "https://www.youtube.com/results?search_query=arrowhead+vine+plant",

        photo: "plantimg/arowhead vine.jfif"
    }
};

// Quotes for the home page
const quotes = [
    "Plants give us oxygen for the lungs and for the soul.",
    "The earth laughs in flowers.",
    "To plant a garden is to believe in tomorrow.",
    "Green is the prime color of the world.",
    "A society grows great when old men plant trees whose shade they know they shall never sit in.",
    "Plants are the silent healers of our planet.",
    "In every walk with nature, one receives far more than he seeks.",
    "The best time to plant a tree was 20 years ago. The second best time is now.",
    "Plants are the poetry of the earth.",
    "Where flowers bloom, so does hope."
];

// Initialize the application
document.addEventListener('DOMContentLoaded', function () {
    // Set up navigation
    setupNavigation();

    // Initialize plant data display
    updatePlantStats();
    displayPlantsGrid();
    populatePlantList();

    // Start quote rotation
    startQuoteRotation();

    // Set up contact form
    setupContactForm();

    // Check for QR code parameter
    checkForQRCode();

    // Create additional floating elements
    createFloatingElements();
});

// Navigation setup
function setupNavigation() {
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        link.addEventListener('click', function (e) {
            e.preventDefault();
            const pageId = this.getAttribute('data-page');
            showPage(pageId);

            // Update active nav link
            navLinks.forEach(l => l.classList.remove('active'));
            this.classList.add('active');
        });
    });
}

// Show specific page
function showPage(pageId) {
    const pages = document.querySelectorAll('.page');
    pages.forEach(page => {
        page.classList.remove('active');
    });
    document.getElementById(pageId).classList.add('active');

    // Scroll to top of the page
    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    });
}

// Update plant statistics on About page
function updatePlantStats() {
    const herbNames = ["Indica", "Bean Plant", "Tulsi", "Gynura Procumbens", "Heena", "Phillipine Tea Tree"];
    const shrubNames = ["Hairy Fig", "Song of India", "Money Plant", "Firespike", "Dwarf Umbrella Tree", "Sida Rhombifolia", "Natal Plum"];
    const treeNames = Object.keys(plantData).filter(name => !herbNames.includes(name) && !shrubNames.includes(name));

    document.getElementById('totalPlants').textContent = Object.keys(plantData).length;
    document.getElementById('herbCount').textContent = herbNames.length;
    document.getElementById('shrubCount').textContent = shrubNames.length;
    document.getElementById('treeCount').textContent = treeNames.length;
}

// Display plants in grid on Plants page
function displayPlantsGrid() {
    const plantsGrid = document.getElementById('plantsGrid');
    plantsGrid.innerHTML = '';

    Object.values(plantData).forEach(plant => {
        const plantCard = document.createElement('div');
        plantCard.className = 'plant-card glass';
        plantCard.innerHTML = `
            <div class="plant-image">
                <img src="${plant.photo}" alt="${plant.name}" />
            </div>
            <div class="plant-info">
                <div class="plant-name">${plant.name}</div>
                <div class="plant-scientific">${plant.scientific_name}</div>
                <span class="plant-type">${plant.type}</span>
            </div>
        `;
        plantCard.addEventListener('click', () => showPlant(plant));
        plantsGrid.appendChild(plantCard);
    });
}


// Populate plant list for the floating container
// Populate plant list for the floating container
function populatePlantList() {
    const plantListContainer = document.getElementById('plantListContainer');
    plantListContainer.innerHTML = ""; // clear pehle

    // Plant names ko sort karna
    const sortedPlantNames = Object.keys(plantData).sort();

    sortedPlantNames.forEach(plantName => {
        const plantItem = document.createElement('div');
        plantItem.className = 'plant-item';
        plantItem.innerHTML = `
            <i class="fas fa-leaf"></i>
            <span>${plantName}</span>
        `;
        plantItem.addEventListener('click', () => {
            showPlant(plantData[plantName]);
            plantListContainer.style.display = 'none';
        });
        plantListContainer.appendChild(plantItem);
    });
}


// Toggle plant list visibility
function togglePlantList() {
    const plantListContainer = document.getElementById('plantListContainer');
    if (plantListContainer.style.display === 'block') {
        plantListContainer.style.display = 'none';
    } else {
        plantListContainer.style.display = 'block';
    }
}

// Local/Hindi name mapping
const localNameMap = {
    "aam": "Mango",
    "goolar": "Hairy Fig",
    "mehndi": "Heena",
    "supari": "Areca palm",
    "money plant": "Money Plant",
    "nimbu": "Bumpy Lemon",
    "nariyal": "Coconut Tree",
    "gudhal": "Hibiscus",
    "ashok": "ashoka Tree",
    "kachnar": "Bauhinia Species",
    "arandi": "castor oil",
    "champa": "Frangipani",
    "bans": "Bamboo",
    "badam": "Almond Tree",
    "sem": "Bean Plant",
    "kathal": "Jackfruit",
    "tejpatta": "Bay Laurel",
    "karonda": "Natal Plum",
    "lasoda": "Lasura",
    "tulsi": "Tulsi",
    "peepal": "Peepal",
    "sitaphal": "Custard Apple",
    "kaju": "Anacus", 
    "Cashew":"Anacus",
    "anacus":"Anacus",  // ya "Cashew" agar data me waise hai
    "amrud": "Guava",
    "madhumalti": "Honeysuckle",
    "tir patta": "Arrowhead Vine"
};

// Search plant function
function searchPlant() {
    const inputElement = document.getElementById('searchInput');
    const input = inputElement.value.trim().toLowerCase();

    if (!input) {
        alert("Please enter a plant name to search.");
        return;
    }

    let key = null;

    // Step 1: Exact English name match (case-insensitive)
    key = Object.keys(plantData).find(p => p.toLowerCase() === input);

    // Step 2: Exact Local name match (case-insensitive)
    if (!key) {
        const localExact = Object.keys(localNameMap).find(local => local.toLowerCase() === input);
        if (localExact) {
            key = localNameMap[localExact];
        }
    }

    // Step 3: Partial English match (contains, case-insensitive)
    if (!key) {
        key = Object.keys(plantData).find(p => p.toLowerCase().includes(input));
    }

    // Step 4: Partial Local name match (contains, case-insensitive)
    if (!key) {
        const localMatch = Object.keys(localNameMap).find(local =>
            local.toLowerCase().includes(input)
        );
        if (localMatch) {
            key = localNameMap[localMatch];
        }
    }

    // Step 5: If still not found
    if (!key || !plantData[key]) {
        alert("Plant not found in our database. Please try another name.");
        return;
    }

    showPlant(plantData[key]);

    // Clear search bar after search
    inputElement.value = "";
}



// Show plant details in popup
function showPlant(plant) {
    document.getElementById('plantName').textContent = plant.name;
    document.getElementById('plantScientific').textContent = plant.scientific_name;
    document.getElementById('plantType').textContent = plant.type;
    document.getElementById('plantHeight').textContent = plant.height;
    document.getElementById('plantLifespan').textContent = plant.lifespan;
    document.getElementById('plantOxygen').textContent = plant.oxygen_level;
    document.getElementById('plantDesc').textContent = plant.description;
    document.getElementById('plantLocation').textContent = plant.location;
    document.getElementById('plantMore').href = plant.more_info_link;
    document.getElementById('plantVideo').href = plant.video_link;
    document.getElementById('plantImage').src = plant.photo;
    document.getElementById('plantImage').alt = plant.name;
    document.getElementById('plantImage').textContent = plant.photo;

    document.getElementById('overlay').style.display = 'block';
    document.getElementById('popup').style.display = 'block';
}

// Close popup
function closePopup() {
    document.getElementById('overlay').style.display = 'none';
    document.getElementById('popup').style.display = 'none';
}

// Like button function
function like() {
    alert("Thank you for liking our Plant Encyclopedia! ❤");
}

// Quote rotation
function startQuoteRotation() {
    let currentQuote = 0;
    const quoteElement = document.getElementById('quote');

    function showNextQuote() {
        quoteElement.textContent = quotes[currentQuote];
        currentQuote = (currentQuote + 1) % quotes.length;
    }

    showNextQuote();
    setInterval(showNextQuote, 5000);
}

// Contact form setup
function setupContactForm() {
    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
        contactForm.addEventListener('submit', function (e) {
            e.preventDefault();
            alert('Thank you for your message! We will get back to you soon.');
            contactForm.reset();
        });
    }
}

// Check for QR code parameter in URL
function checkForQRCode() {
    const urlParams = new URLSearchParams(window.location.search);
    const plantNameFromQuery = urlParams.get('plant');
    const plantNameFromHash = window.location.hash.substring(1);

    let selectedPlant = null;

    if (plantNameFromQuery && plantData[plantNameFromQuery]) {
        selectedPlant = plantData[plantNameFromQuery];
    } else if (plantNameFromHash && plantData[plantNameFromHash]) {
        selectedPlant = plantData[plantNameFromHash];
    }

    if (selectedPlant) {
        showPlant(selectedPlant);
    }
}


// Create additional floating elements for background
function createFloatingElements() {
    const container = document.querySelector('.floating-elements');
    for (let i = 0; i < 8; i++) {
        const size = Math.random() * 100 + 50;
        const element = document.createElement('div');
        element.className = 'floating-element';
        element.style.width = `${size}px`;
        element.style.height = `${size}px`;
        element.style.top = `${Math.random() * 100}%`;
        element.style.left = `${Math.random() * 100}%`;
        element.style.animationDuration = `${Math.random() * 20 + 10}s`;
        element.style.animationDelay = `${Math.random() * 5}s`;
        container.appendChild(element);
    }

}


// Add event listener to the View Plants button
document.getElementById('viewPlantsBtn').addEventListener('click', togglePlantList);
